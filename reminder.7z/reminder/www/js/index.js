
var app = {
    cpt: 0,
    tempss:0,
    heure:0,
    minute:0,
    tableauDonnees:0,
    compteure:0,
    db:null,
    // Application Constructor
    initialize: function() {
        if(window.cordova){
            document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
        }
        else{
            this.onDeviceReady();
            console.log("navigateur");
        }
    },

    onDeviceReady: function() {
        cordova.plugins.backgroundMode.enable();
        cordova.plugins.backgroundMode.overrideBackButton();
        cordova.plugins.backgroundMode.excludeFromTaskList();
        var tableau = new Array();

        //$('#ajoutAlarme').hide();
        $('#selectionJour').hide();

        this.setDeviceReady();

        var tableauDonnees = 0;
        db = window.sqlitePlugin.openDatabase({name: 'demo.db', location: 'default'});

/*            db.transaction(function(tx){
            tx.executeSql('DROP TABLE alarme');
        });*/
        var heure = 11;
        var minute = 25;
        var seconde = 50;
        db.executeSql('INSERT INTO alarme VALUES (?,?,?)', [heure, minute, seconde]);

        this.essai();
        //console.log(nombreDeLigne);



        db.transaction(function(tx) {

            tx.executeSql('CREATE TABLE IF NOT EXISTS alarme (heure INT,minute INT,seconde INT)');

            tx.executeSql('SELECT count(*) AS ligne FROM alarme', [], function(tx, rs) {
                nombreDeLigne = rs.rows.item(0).ligne;
                console.log('nbr de ligne = ' + nombreDeLigne);
            }, function(tx, error) {
                console.log('SELECT error: ' + error.message);
            });

            tx.executeSql('SELECT seconde AS test FROM alarme', [], function(tx, rs) {
                for (var i = 0 ; i < nombreDeLigne ; i++){
                    var remplissage = rs.rows.item(i).test;
                    console.log('ligne '+ i + ' = ' + remplissage);
                    tableau.push(rs.rows.item(i).test);
                }
                console.log('taille du tableau = '+ tableau.length);
            }, function(tx, error) {
                console.log('SELECT error: ' + error.message);
            });

        });

/*        function selectRow(query, callBack){ // <-- extra param
            var result = [];
            db.transaction(function (tx) {
                tx.executeSql(query, [], function(tx, rs){
                    for(var i=0; i<rs.rows.length; i++) {
                        var row = rs.rows.item(i);
                        result[i] = { seconde: row['seconde']
                        }
                    }
                    console.log(result);
                    callBack(result); // <-- new bit here
                }, errorHandler);
            });
        }
        selectRow();*/

        this.start();

        this.ajouterAlarme();

    },

/*    teste: function () {
        console.log("fonction test marche");
        var storage = window.localStorage;
        for(i = 0 ; i < this.compteure; i++){
            var value = storage.getItem(i);
            console.log('test : ' + value);
        }

    },*/
    essai: function () {
        console.log('avant test');
        db.executeSql('SELECT count(*) AS ligne FROM alarme', [], function(tx, rs) {
            nombreDeLigne = rs.rows.item(0).ligne;
            console.log('nbr de ligne = ' + nombreDeLigne);
        }, function(tx, error) {
            console.log('SELECT error: ' + error.message);
        });
        console.log('apres test');
    },
    ajouterAlarme : function(){
        $("#ajoutAlarme").change(function () {
/*            console.log(this.compteure);*/
/*
            alert(this.nombreDeLigne);
            if(this.nombreDeLigne < 5) {

*/
            var hs = $("#ajoutAlarme").val();
            var res = hs.split(":");
            var heure = res[0];
            var minute = res[1];
            var seconde = (res[0] * 3600 + res[1] * 60);

/*            var storage = window.localStorage;
            storage.setItem(this.compteure, seconde);

            for(i = 0 ; i < this.compteure; i++){
                var value = storage.getItem(i);
                console.log('test : ' + value);
            }

            this.compteure ++;

            console.log('valeur du compteure = '+ (this.compteure));*/


            db.transaction(function (tx) {
                tx.executeSql('CREATE TABLE IF NOT EXISTS alarme (heure INT,minute INT,seconde INT)');
                tx.executeSql('INSERT INTO alarme VALUES (?,?,?)', [heure, minute, seconde]);
            }, function (error) {
                console.log('Transaction ERROR: ' + error.message);
            }, function () {
                console.log('Populated database OK');
            });

            var heureSave = document.createTextNode($("#ajoutAlarme").val());
            var hr = document.createElement("hr");
            $('#reveilEnregistre').append(heureSave);
            $('#reveilEnregistre').css("font-size", "3em");
            $('#reveilEnregistre').append(hr);
        });



/*            else{
                alert("4 alarmes maximum");
            }*/

        //});
    },


    notification: function(){
        cordova.plugins.notification.local.schedule({
            title: 'Alarme',
            text: 'Reminder',
            foreground: true
        });
    },

    vibrerTouteLesTroisSecondes: function(){
        navigator.vibrate([300,3000,200,3000,500,3000,300,3000,1000]);
    },

    setDeviceReady: function(){
        $("#Online").show();
        $("#Offline").hide();
    },


    start: function(){
        var date = new Date();
        var heure = date.getHours();
        var minute = date.getMinutes();
        var tempss = heure * 3600 + minute * 60;
        var tempsa = parseInt(17 * 3600 + 32 * 60);
        var bip = 30;

        setInterval(function(){
            this.cpt++;
            var date = new Date();
            this.heure = date.getHours();
            this.minute = date.getMinutes();
            this.tempss = heure * 3600 + minute * 60;

            //console.log(nombreDeLigne);
            /*if (this.tempss === bip){
                this.notification();
                this.vibrerTouteLesTroisSecondes();
            }*/

            this.updateDom();

        }.bind(this),10000);
    },

    updateDom: function(){

/*        $("#squareHeureActuel").html(this.heure);
        if(this.minute < 10){
            $("#squareMinuteActuel").html("0"+this.minute);
        }
        else{
            $("#squareMinuteActuel").html(this.minute);
        }*/
        //this.recupInfoReveil();

    }
};

app.initialize();